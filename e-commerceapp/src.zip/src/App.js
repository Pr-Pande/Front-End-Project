import './App.css';
import {
  BrowserRouter as Router,
  Routes,
  Route
} from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import Product from './components/products';
import Menubar from './components/menubar';
import ProductDetails from './components/productdetails';

function App() {

  return (
    <div className="App" style={{ backgroundColor: '#f5f5f5' }}>
      <Router>
        <Menubar />
        <Routes>
          <Route exact path='/' element={<Product />} />
          <Route path="/Product/:id" element={<ProductDetails />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
