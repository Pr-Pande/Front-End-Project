import React from "react";
import { Link } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';

const ProductDetails = ({ product }) => {

    //console.log(product); // Add this line to check if the product object is populated

    /*if (!product) {
        return <div>Product not found</div>;
    } */

    return (
        <div className="product-details-container" style={{ backgroundColor: "#f5f5f5", padding: "20px" }}>
            <div className="container my-5 py-3">
                <div className="row">
                    <div className="col-12 text-center">
                        <h1 className="fw-bold" style={{ color: "#00008b" }}> {product.title} </h1>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-6">
                        <img src={product.img} className="product-image" alt={product.title} height="300px" />
                    </div>
                    <div className="col-md-6">
                        <h3 className="fw-bold"> Model : {product.title} </h3>
                        <h5 className="fw-bold" style={{ color: "#808080" }}> MADE BY : {product.comp} </h5>
                        <h5 className="fw-bold" style={{ color: "#483d8b" }}> Price : ${product.price} </h5>
                        <p className="fw-bold"> Some Info About Product</p>
                        <p className="fw-bold" style={{ color: "#778899" }}> {product.desc} </p>
                        <div className="d-flex">
                            <Link to={'/'}>
                                <button /*onClick={()=>handleCart(product)}*/ className="btn btn-outline-primary">Back To Products</button>
                            </Link>
                            <button className="btn btn-outline-warning">Add To Cart</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    )
}

export default ProductDetails;

