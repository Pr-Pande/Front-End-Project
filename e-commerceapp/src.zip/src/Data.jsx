const DATA = [
    {
        id: 1,
        title: "Google Pixel-Black",
        comp: "GOOGLE",
        price: 10,
        desc: "The Google Pixel 4a is more than just another smartphone for your tasks! Its HDR+ will help you take stunning photos.\n \
                The Night Sight mode with astrophotography is just what you need to click those stunning images of the star-lit skies you have been meaning to capture.\n \
                This phone also features apps such as the Pixel Recorder app that transcribes speech automatically.",
        img: "./imgs/Reactproject phone1.jpeg"
    },
    {
        id: 2,
        title: "Samsung S7",
        comp: "SAMSUNG",
        price: 16,
        desc: "The Google Pixel 4a is more than just another smartphone for your tasks! Its HDR+ will help you take stunning photos.\n \
                The Night Sight mode with astrophotography is just what you need to click those stunning images of the star-lit skies you have been meaning to capture.\n \
                This phone also features apps such as the Pixel Recorder app that transcribes speech automatically.",
        img: "./imgs/Reactproject phone2.jpg"
    },
    {
        id: 3,
        title: "HTC 10-Black",
        comp: "HTC",
        price: 8,
        desc: "The Google Pixel 4a is more than just another smartphone for your tasks! Its HDR+ will help you take stunning photos.\n \
                The Night Sight mode with astrophotography is just what you need to click those stunning images of the star-lit skies you have been meaning to capture.\n \
                This phone also features apps such as the Pixel Recorder app that transcribes speech automatically.",
        img: "./imgs/Reactproject phone3.jpeg"
    },
    {
        id: 4,
        title: "HTC 10-White",
        comp: "HTC",
        price: 18,
        desc: "The Google Pixel 4a is more than just another smartphone for your tasks! Its HDR+ will help you take stunning photos.\n \
                The Night Sight mode with astrophotography is just what you need to click those stunning images of the star-lit skies you have been meaning to capture.\n \
                This phone also features apps such as the Pixel Recorder app that transcribes speech automatically.",
        img: "./imgs/Reactproject phone4.webp"
    },
    {
        id: 5,
        title: "HTC Desire 626s",
        comp: "HTC",
        price: 24,
        desc: "The Google Pixel 4a is more than just another smartphone for your tasks! Its HDR+ will help you take stunning photos.\n \
                The Night Sight mode with astrophotography is just what you need to click those stunning images of the star-lit skies you have been meaning to capture.\n \
                This phone also features apps such as the Pixel Recorder app that transcribes speech automatically.",
        img: "./imgs/Reactproject phone5.jpeg"
    },
    {
        id: 6,
        title: "Motorola Moto G8",
        comp: "MOTOROLA",
        price: 17,
        desc: "The Google Pixel 4a is more than just another smartphone for your tasks! Its HDR+ will help you take stunning photos.\n \
                The Night Sight mode with astrophotography is just what you need to click those stunning images of the star-lit skies you have been meaning to capture.\n \
                This phone also features apps such as the Pixel Recorder app that transcribes speech automatically.",
        img: "./imgs/Reactproject phone6.jpg"
    },
    {
        id: 7,
        title: "iPhone 8",
        comp: "APPLE",
        price: 30,
        desc: "The Google Pixel 4a is more than just another smartphone for your tasks! Its HDR+ will help you take stunning photos.\n \
                The Night Sight mode with astrophotography is just what you need to click those stunning images of the star-lit skies you have been meaning to capture.\n \
                This phone also features apps such as the Pixel Recorder app that transcribes speech automatically.",
        img: "./imgs/Reactproject phone7.jpg"
    },
    {
        id: 8,
        title: "Smashed iPhone",
        comp: "APPLE",
        price: 2,
        desc: "The Google Pixel 4a is more than just another smartphone for your tasks! Its HDR+ will help you take stunning photos.\n \
                The Night Sight mode with astrophotography is just what you need to click those stunning images of the star-lit skies you have been meaning to capture.\n \
                This phone also features apps such as the Pixel Recorder app that transcribes speech automatically.",
        img: "./imgs/Reactproject phone8.jpeg"
    }
]

export default DATA;